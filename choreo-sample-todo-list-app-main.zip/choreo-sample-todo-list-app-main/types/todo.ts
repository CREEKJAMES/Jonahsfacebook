export interface ToDo {
  id: number;
  task: string;
  done?: boolean;
}
